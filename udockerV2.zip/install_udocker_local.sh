#!/bin/bash
#
# install_udocker_local.sh
# Pasang udocker (dari repo lokal ini) untuk user biasa:
#   - kode    -> ~/.local/share/udocker
#   - launcher-> ~/.local/bin/udocker
#
# Usage: bash install_udocker_local.sh
# Tanpa root. Tanpa network (kecuali `udocker install` engine nanti).

set -u

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Direktori sumber = tempat skrip ini berada
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "${SRC_DIR}/udocker/maincmd.py" ]; then
    log_error "Repo udocker tidak ditemukan di ${SRC_DIR}"
    log_error "Jalankan skrip ini dari root repo udocker"
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    log_error "python3 tidak ditemukan"
    exit 1
fi

SHARE_DIR="${HOME}/.local/share/udocker"
BIN_DIR="${HOME}/.local/bin"

# ---- Step 1: Salin repo ke ~/.local/share/udocker ----
log_info "Memasang udocker ke ${SHARE_DIR}..."

mkdir -p "${SHARE_DIR}" "${BIN_DIR}" || {
    log_error "Tidak bisa membuat ${SHARE_DIR} atau ${BIN_DIR}"
    exit 1
}

# Hapus instalasi lama
if [ -d "${SHARE_DIR}" ]; then
    rm -rf "${SHARE_DIR}"
fi

# Salin source (kecuali file temporary / sandbox)
cp -r "${SRC_DIR}/udocker" "${SHARE_DIR}/udocker"

# bersihkan __pycache__ jika ada
find "${SHARE_DIR}" -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true

log_info "Source udocker terpasang"

# ---- Step 2: Pasang launcher ke ~/.local/bin/udocker ----
log_info "Memasang launcher ke ${BIN_DIR}/udocker..."

cp "${SRC_DIR}/udocker_launcher.py" "${BIN_DIR}/udocker"
chmod 755 "${BIN_DIR}/udocker"

# ---- Step 3: Verifikasi ----
if [ -x "${BIN_DIR}/udocker" ]; then
    log_info "Instalasi selesai"
    echo ""
    echo "  Binary   : ${BIN_DIR}/udocker"
    echo "  Source   : ${SHARE_DIR}/udocker"
    echo ""
    # Test jalankan
    if "${BIN_DIR}/udocker" version >/dev/null 2>&1; then
        log_info "Verifikasi: udocker berjalan"
        "${BIN_DIR}/udocker" version
    else
        log_warn "udocker terpasang tapi 'version' gagal"
        log_warn "Coba: ${BIN_DIR}/udocker --help"
    fi
    echo ""
    if [[ ":${PATH}:" != *":${BIN_DIR}:"* ]]; then
        log_warn "${BIN_DIR} belum ada di PATH"
        log_warn "Tambahkan baris ini ke ~/.bashrc lalu jalankan 'source ~/.bashrc':"
        echo "  export PATH=\"${BIN_DIR}:\${PATH}\""
    fi
else
    log_error "Gagal memasang launcher"
    exit 1
fi
