#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
udocker launcher (user-level install)

Mengeksekusi udocker dari direktori instalasi user (~/.local/share/udocker).
Dipasang di ~/.local/bin/udocker oleh install_udocker_local.sh
"""

import os
import sys

INSTALL_DIR = os.path.expanduser("~/.local/share/udocker")
MAINCMD = os.path.join(INSTALL_DIR, "udocker", "maincmd.py")

if not os.path.isfile(MAINCMD):
    sys.stderr.write("Error: udocker tidak ditemukan di %s\n" % INSTALL_DIR)
    sys.stderr.write("Jalankan ulang install_udocker_local.sh\n")
    sys.exit(1)

# maincmd.py meng-append dirname(argv[0]) + '/../' ke sys.path, yang
# menghasilkan INSTALL_DIR. Tambahkan juga via PYTHONPATH agar import
# paket udocker selalu berhasil terlepas dari cara pemanggilan.
os.environ["PYTHONPATH"] = INSTALL_DIR + os.pathsep + \
    os.environ.get("PYTHONPATH", "")

os.execv(sys.executable, [sys.executable, MAINCMD] + sys.argv[1:])
