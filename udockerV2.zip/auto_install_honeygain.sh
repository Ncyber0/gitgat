#!/bin/bash
#
# auto_install_honeygain.sh
# Pasang Honeygain container memakai udocker (dari instalasi user biasa)
#
# Usage: bash auto_install_honeygain.sh <EMAIL> <PASSWORD> <DEVICE_NAME>
#
# Membutuhkan: ~/.local/bin/udocker (dipasang oleh install_udocker_local.sh)

set -u

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

if [ $# -ne 3 ]; then
    echo "Usage: $0 <EMAIL> <PASSWORD> <DEVICE_NAME>"
    exit 1
fi

HONEYGAIN_EMAIL="$1"
HONEYGAIN_PASS="$2"
HONEYGAIN_DEVICE="$3"

# ---- Cek udocker binary ----
if ! command -v udocker >/dev/null 2>&1; then
    UDOCKER_BIN="${HOME}/.local/bin/udocker"
    if [ ! -x "${UDOCKER_BIN}" ]; then
        log_error "udocker tidak ditemukan. Jalankan dulu:"
        echo "  bash install_udocker_local.sh"
        exit 1
    fi
else
    UDOCKER_BIN="$(command -v udocker)"
fi

log_info "Menggunakan udocker: ${UDOCKER_BIN}"

BASE_DIR="$(pwd)"
LOG_FILE="${BASE_DIR}/honey.log"
PID_FILE="${BASE_DIR}/honey.pid"

# Detect real home
REAL_HOME="$(cd ~ 2>/dev/null && pwd)"
[ -d "${REAL_HOME}" ] || REAL_HOME="${HOME}"

# Lokasi repo udocker
export UDOCKER_DIR="${REAL_HOME}/.udocker"

# Quiet mode
export UDOCKER_LOGLEVEL=2

_udocker() { "${UDOCKER_BIN}" "$@"; }

# ---- Step 1: Install udocker engines ----
log_info "Installing udocker engines..."
if _udocker install; then
    log_info "Engine udocker terinstall"
else
    log_warn "udocker install gagal/sebagian. Mencoba lanjut."
fi

# ---- Step 2: Pull image ----
log_info "Pulling honeygain/honeygain..."
if ! _udocker --quiet pull honeygain/honeygain; then
    log_error "Pull image gagal"
    exit 1
fi

# ---- Step 3: /tmp noexec workaround ----
UDOCKER_TMP="${UDOCKER_DIR}/tmp"
mkdir -p "${UDOCKER_TMP}"
export PROOT_TMP_DIR="${UDOCKER_TMP}"
log_info "PROOT_TMP_DIR=${UDOCKER_TMP}"

# ---- Step 4: Buat container ----
CONTAINER_NAME="honeygain_${HONEYGAIN_DEVICE}"

if _udocker ps | grep -q "${CONTAINER_NAME}"; then
    log_info "Removing existing container '${CONTAINER_NAME}'..."
    _udocker rm "${CONTAINER_NAME}" 2>/dev/null || true
fi

log_info "Creating container: ${CONTAINER_NAME}"
if ! _udocker create --name="${CONTAINER_NAME}" honeygain/honeygain; then
    log_error "create container gagal"
    exit 1
fi

# ---- Step 5: Execution mode ----
log_info "Configuring execution mode F3..."
if ! _udocker setup --execmode=F3 "${CONTAINER_NAME}" 2>/dev/null; then
    log_warn "F3 gagal, mencoba P2..."
    _udocker setup --execmode=P2 "${CONTAINER_NAME}" 2>/dev/null \
        || log_warn "Menggunakan mode default."
fi

# ---- Step 6: Run Honeygain ----
log_info "Starting Honeygain in background (log: ${LOG_FILE})..."

nohup "${UDOCKER_BIN}" run "${CONTAINER_NAME}" \
    -tou-accept \
    -email "${HONEYGAIN_EMAIL}" \
    -pass "${HONEYGAIN_PASS}" \
    -device "${HONEYGAIN_DEVICE}" \
    >> "${LOG_FILE}" 2>&1 &

HONEY_PID=$!
echo "${HONEY_PID}" > "${PID_FILE}"

sleep 5
if kill -0 "${HONEY_PID}" 2>/dev/null; then
    log_info "Honeygain running (PID: ${HONEY_PID})"
    log_info "View logs:  tail -f ${LOG_FILE}"
    log_info "[/REMOTE]  kill \$(cat ${PID_FILE})"
    echo ""
    echo "--- Last 10 lines of honey.log ---"
    tail -10 "${LOG_FILE}" 2>/dev/null || true
else
    log_error "Honeygain failed to start. Check ${LOG_FILE}:"
    tail -20 "${LOG_FILE}" 2>/dev/null || true
    exit 1
fi

log_info "Dashboard: https://dashboard.honeygain.com/"
