#!/bin/bash
#
# auto_install_honeygain.sh
# Auto-install udocker (dari repo lokal hasil update) + Honeygain container
# Mode: background, kredensial dibaca dari file (tidak terlihat di ps)
#
# Usage:
#   bash auto_install_honeygain.sh <REPO_PATH> <CRED_FILE> <DEVICE_NAME>
#
#   REPO_PATH   : path absolut ke repo udocker (berisi udocker/maincmd.py)
#   CRED_FILE   : file berisi EMAIL dan PASSWORD, format:
#                 HONEYGAIN_EMAIL=...
#                 HONEYGAIN_PASS=...
#                 (buat dengan: install -m600 /dev/null cred.txt lalu edit)
#   DEVICE_NAME : nama device di dashboard Honeygain

set -u

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

if [ $# -ne 3 ]; then
    echo "Usage: $0 <REPO_PATH> <CRED_FILE> <DEVICE_NAME>"
    echo ""
    echo "Buat file kredensial dulu:"
    echo "  install -m600 /dev/null ~/hg_cred.txt"
    echo "  cat > ~/hg_cred.txt <<'EOF'"
    echo "  HONEYGAIN_EMAIL=email@gmail.com"
    echo "  HONEYGAIN_PASS=password-rahasia"
    echo "  EOF"
    exit 1
fi

REPO_PATH="$1"
CRED_FILE="$2"
HONEYGAIN_DEVICE="$3"

# ---- Validasi input ----
if [ ! -f "${REPO_PATH}/udocker/maincmd.py" ]; then
    log_error "Repo udocker tidak valid: ${REPO_PATH}/udocker/maincmd.py tidak ada"
    exit 1
fi

if [ ! -f "${CRED_FILE}" ]; then
    log_error "File kredensial tidak ada: ${CRED_FILE}"
    exit 1
fi

# Cek permission file kredensial (harus 600)
PERM=$(stat -c '%a' "${CRED_FILE}" 2>/dev/null || stat -f '%A' "${CRED_FILE}" 2>/dev/null)
if [ "${PERM}" != "600" ]; then
    log_warn "Permission ${CRED_FILE} = ${PERM}, seharusnya 600"
    log_warn "Perbaiki dengan: chmod 600 ${CRED_FILE}"
fi

# Baca kredensial (tidak muncul di command line)
HONEYGAIN_EMAIL=$(grep -E '^HONEYGAIN_EMAIL=' "${CRED_FILE}" | head -1 | cut -d= -f2-)
HONEYGAIN_PASS=$(grep -E '^HONEYGAIN_PASS=' "${CRED_FILE}" | head -1 | cut -d= -f2-)

if [ -z "${HONEYGAIN_EMAIL}" ] || [ -z "${HONEYGAIN_PASS}" ]; then
    log_error "HONEYGAIN_EMAIL atau HONEYGAIN_PASS kosong di ${CRED_FILE}"
    exit 1
fi

BASE_DIR="$(pwd)"
LOG_FILE="${BASE_DIR}/honey.log"
PID_FILE="${BASE_DIR}/honey.pid"

# Detect real home (hosting panels kadang set HOME=/)
REAL_HOME="$(cd ~ 2>/dev/null && pwd)"
[ -d "${REAL_HOME}" ] || REAL_HOME="${HOME}"

# ---- Step 1: Siapkan udocker dari repo lokal ----
log_info "Menggunakan udocker dari repo lokal: ${REPO_PATH}"

if [ ! -f "${REPO_PATH}/udocker/maincmd.py" ]; then
    log_error "maincmd.py tidak ditemukan di ${REPO_PATH}/udocker/"
    exit 1
fi

chmod +x "${REPO_PATH}/udocker/maincmd.py" 2>/dev/null || true

# Repo mode: UDOCKER_DIR menentukan lokasi repo udocker (default ~/.udocker)
export UDOCKER_DIR="${REAL_HOME}/.udocker"

# Quiet mode (level 2 = Msg.MSG, hanya pesan penting)
export UDOCKER_LOGLEVEL=2

# python3 wajib ada
if ! command -v python3 >/dev/null 2>&1; then
    log_error "python3 tidak ditemukan"
    exit 1
fi

_udocker() { python3 "${REPO_PATH}/udocker/maincmd.py" "$@"; }

# ---- Step 2: Install udocker engines (proot, fakechroot, dll) ----
log_info "Installing udocker engines (butuh koneksi internet)..."
if _udocker install; then
    log_info "Engine udocker terinstall"
else
    log_warn "udocker install gagal/sebagian. Mencoba lanjut dengan engine yang ada."
fi

# ---- Step 3: Pull honeygain image ----
log_info "Pulling honeygain/honeygain..."
if ! _udocker --quiet pull honeygain/honeygain; then
    log_error "Pull image honeygain/honeygain gagal"
    exit 1
fi

# ---- Step 4: Fix /tmp noexec ----
UDOCKER_TMP="${UDOCKER_DIR}/tmp"
mkdir -p "${UDOCKER_TMP}"
export PROOT_TMP_DIR="${UDOCKER_TMP}"
log_info "PROOT_TMP_DIR=${UDOCKER_TMP}"

# ---- Step 5: Create container ----
CONTAINER_NAME="honeygain_${HONEYGAIN_DEVICE}"

if _udocker ps | grep -q "${CONTAINER_NAME}"; then
    log_info "Removing existing container '${CONTAINER_NAME}'..."
    _udocker rm "${CONTAINER_NAME}" 2>/dev/null || true
fi

log_info "Creating container: ${CONTAINER_NAME}"
if ! _udocker create --name="${CONTAINER_NAME}" honeygain/honeygain; then
    log_error "create container gagal"
    exit 1
fi

# ---- Step 6: Set execution mode ----
log_info "Configuring execution mode F3..."
if ! _udocker setup --execmode=F3 "${CONTAINER_NAME}" 2>/dev/null; then
    log_warn "F3 gagal, mencoba P2..."
    _udocker setup --execmode=P2 "${CONTAINER_NAME}" 2>/dev/null \
        || log_warn "Menggunakan mode default."
fi

# ---- Step 7: Run Honeygain di background ----
# Kredensial dibaca dari file oleh wrapper saat proses sudah berjalan,
# sehingga TIDAK muncul di `ps aux` (argumen command line kosong).
RUN_WRAPPER="${BASE_DIR}/.hg_run_wrapper.sh"
cat > "${RUN_WRAPPER}" <<'WRAPPER_EOF'
#!/bin/bash
# Wrapper: baca kredensial dari file, lalu jalankan udocker run.
# Dibuat oleh auto_install_honeygain.sh
CRED_FILE="__CRED_FILE__"
REPO_PATH="__REPO_PATH__"
CONTAINER_NAME="__CONTAINER_NAME__"
LOG_FILE="__LOG_FILE__"

EMAIL=$(grep -E '^HONEYGAIN_EMAIL=' "${CRED_FILE}" | head -1 | cut -d= -f2-)
PASS=$(grep -E '^HONEYGAIN_PASS=' "${CRED_FILE}" | head -1 | cut -d= -f2-)

exec python3 "${REPO_PATH}/udocker/maincmd.py" run "${CONTAINER_NAME}" \
    -tou-accept \
    -email "${EMAIL}" \
    -pass "${PASS}" \
    -device "$(grep -E '^HONEYGAIN_DEVICE=' "${CRED_FILE}" | head -1 | cut -d= -f2-)" \
    >> "${LOG_FILE}" 2>&1
WRAPPER_EOF
chmod 700 "${RUN_WRAPPER}"

# Substitusi placeholder (nilai tidak akan muncul di ps karena wrapper
# dieksekusi sebagai file, bukan via command line)
sed -i \
    -e "s|__CRED_FILE__|${CRED_FILE}|g" \
    -e "s|__REPO_PATH__|${REPO_PATH}|g" \
    -e "s|__CONTAINER_NAME__|${CONTAINER_NAME}|g" \
    -e "s|__LOG_FILE__|${LOG_FILE}|g" \
    "${RUN_WRAPPER}"

log_info "Starting Honeygain in background (log: ${LOG_FILE})..."

nohup bash "${RUN_WRAPPER}" >/dev/null 2>&1 &

HONEY_PID=$!
echo "${HONEY_PID}" > "${PID_FILE}"

# ---- Step 8: Cek status ----
sleep 5
if kill -0 "${HONEY_PID}" 2>/dev/null; then
    log_info "Honeygain running (PID: ${HONEY_PID})"
    log_info "View logs:  tail -f ${LOG_FILE}"
    log_info "Stop:       kill \$(cat ${PID_FILE})"
    echo ""
    echo "--- Last 10 lines of honey.log ---"
    tail -10 "${LOG_FILE}" 2>/dev/null || true
else
    log_error "Honeygain failed to start. Check ${LOG_FILE}:"
    tail -20 "${LOG_FILE}" 2>/dev/null || true
    exit 1
fi

log_info "Dashboard: https://dashboard.honeygain.com/"
